<?php
if(isset($_POST['submit'])){

    //collect form data
    $city = $_POST['city'];
    $venue = $_POST['venue'];
    $team1 = $_POST['team1'];
	 $team2 = $_POST['team2'];
    $toss = $_POST['toss'];
    $deision = $_POST['deision'];

    

    //if no errors carry on
    if(!isset($error)){

        // Title of the CSV
              $Content = "city,venue,team1,team2,toss,decision\n";

        //set the data of the CSV
        $Content .= "$city,$venue,$team1,$team2,$toss,$decision\n";

        //set the file name and create CSV file
        $FileName = $city."-".date("d-m-y-h:i:s").".csv";
        header('Content-Type: application/csv'); 
        header('Content-Disposition: attachment; filename="' . $FileName . '"'); 
        echo $Content;
        exit();
    }
}

//if their are errors display them
    if(isset($error)){
      foreach($error as $error){
        echo '<p style="color:#ff0000">$error</p>';
   }
}
?> 




<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>match predictor</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
		<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<style>
		
	
		
		
		
.dropdown-submenu {
  position: relative;
}

.dropdown-submenu .dropdown-menu {
  top: 0;
  left: 100%;
  margin-top: -1px;
}




body {
   
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 300px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 6px 6px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.button5 {background-color: #555555;}

.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
    </head>
    <body style="background-image: url('images/ipl6.jpg'); background-repeat: no-repeat;">
	
	<div class="sidenav">
	<a href="final webapp\DevFolio\index.html">IPL 20-20</a><br><br>
	<a href="main1.php">Home</a><br><br>
<a href="final webapp\DevFolio\pastperformance.html">Past Performance</a><br><br>
<a href="select.php">IPL Match Predictor</a><br><br>
  <a href="select2.php">IPL Season Predictor</a><br><br>
  <a href="final webapp\New folder\charts\HTML-Table-Based-Column-Chart-Plugin-For-jQuery-graph-js/index.html">IPL Team Performance</a><br><br>
  <a href="logout.php">Logout</a><br>
    
</div>
	
        <div class="container">
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-9 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <form id="reused_form"  action="" method="post">
                                    <div class="main">
 
</div><br><br><br>


	<div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
		<div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
			<form class="contact100-form validate-form">
				<span class="contact100-form-title">
					IPl 20-20 Match Predictor
				</span>
				
			
				<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.js"></script>
	<script type="text/javascript">
	$(function(){
		$('select').change(function(){ // when one changes
			$('select').val( $(this).val() ) // they all change
		})
	})
	</script>
	
	
	
				<div class="wrap-input100 input100-select">
					<span class="label-input100">venue</span>
					<div>
						<select id="city" name="city">
  <option value="1" >Hyderabad</option>
  <option value="2" >Pune</option>
  <option value="3" >Rajkot</option>
  <option value="4" >Indore</option>
  <option value="5" >Bangalore</option>
  <option value="6" >Mumbai</option>
  <option value="7" >Kolkata</option>
  <option value="Delhi" >Delhi</option>
  <option value="Chandigarh" >Chandigarh</option>
  <option value="Kanpur" >Kanpur</option>
  <option value="Jaipur" >Jaipur</option>
  <option value="Chennai" >Chennai</option>
  <option value="Cape Town" >Cape Town</option>
  <option value="Port Elizabeth" >Port Elizabeth</option>
  <option value="Durban" >Durban</option>
  <option value="Centurion" >Centurion</option>
  <option value="East London" >East London</option>
  <option value="Johannesburg" >Johannesburg</option>
  <option value="Kimberley" >Kimberley</option>
  <option value="Bloemfontein" >Bloemfontein</option>
  <option value="Ahmedabad" >Ahmedabad</option>
  <option value="Cuttack" >Cuttack</option>

 
</select>

<select  id="venue" name="venue">
  <option value="1">Rajiv Gandhi International Stadium, Uppal</option>
  <option value="2">Maharashtra Cricket Association Stadium</option>
   <option value="3" >Saurashtra Cricket Association Stadium</option>
  <option value="4">Holkar Cricket Stadium</option>
  <option value="5" >M Chinnaswamy Stadium</option>
  <option value="6" >Wankhede Stadium</option>
  <option value="7" >Eden Gardens</option>
  <option value="Feroz Shah Kotla" >Feroz Shah Kotla</option>
  <option value="Punjab Cricket Association IS Bindra Stadium, Mohali" >Punjab Cricket Association IS Bindra Stadium, Mohali</option>
  <option value="Green Park" >Green Park</option>
  <option value="Sawai Mansingh Stadium" >Sawai Mansingh Stadium</option>
  <option value="MA Chidambaram Stadium, Chepauk" >MA Chidambaram Stadium, Chepauk</option>
  <option value="Newlands" >Newlands</option>
  <option value="St George's Park" >St George's Park</option>
  <option value="Kingsmead" >Kingsmead</option>
  <option value="SuperSport Park" >SuperSport Park</option>
  <option value="Buffalo Park" >Buffalo Park</option>
  <option value="New Wanderers Stadium" >New Wanderers Stadium</option>
  <option value="De Beers Diamond Oval" >De Beers Diamond Oval</option>
  <option value="OUTsurance Oval" >OUTsurance Oval</option>
  <option value="Sardar Patel Stadium, Motera" >Sardar Patel Stadium, Motera</option>
  <option value="Barabati Stadium" >Barabati Stadium</option>

</select>
</div>
	
	
	
	
	<div class="wrap-input100 input100-select">
					<span class="label-input100">Team 1</span>
					<div>
						<select class="selection-2" name="team1" id="team1">
						<option>Chennai Super Kings</option>
						<option >Royal Challengers Bangalore</option>
							<option>Mumbai Indians</option>
							<option>Kings XI Punjab</option>
							<option>Delhi Capitals</option>
							<option>Rajasthan Royals</option>
							<option>SunRisers Hyderabad</option>
							<option>Kolkata Knight Riders</option>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div><br>
				
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Team 2</span>
					<div>
						<select class="selection-2" name="team2" id="team2">
						<option >Royal Challengers Bangalore</option>
						<option>Chennai Super Kings</option>
							<option>Mumbai Indians</option>
							<option>Kings XI Punjab</option>
							<option>Delhi Capitals</option>
							<option>Rajasthan Royals</option>
							<option>SunRisers Hyderabad</option>
							<option>Kolkata Knight Riders</option>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div><br>
				
				
				

				
				
<div class="wrap-input100 input100-select">
					<span class="label-input100">Toss won by</span>
					<div>
						<select class="selection-2" name="toss" id="toss">
							<option>Team 1</option>
							<option>Team 2</option>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div><br>
				
				
				

	
	
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Toss Decision</span>
					<div>
						<select class="selection-2" name="decision" id="decision">
							<option>Field</option>
							<option>Bat</option>
							
						</select>
					</div>
					<span class="focus-input100"></span>
				</div><br>

	
	
				
				
			
				
    
				
				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div><button class="contact100-form-btn" style="background-color:black;">
						
				<input type="submit" name="submit"   value="Get CSV File" style="background-color:black;">
                      <!--  <a href="C:\Users\asahana\Desktop\final webapp\New folder\result.html">
							
								Predict
								
						</a>-->
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>



	<div id="dropDownSelect1"></div>
                                </form>
                                <div id="error_message" style="width:100%; height:100%; display:none; ">
                                    <h4>
                                        Error
                                    </h4>
                                    Sorry there was an error sending your form. 
                                </div>
                                <div id="success_message" style="width:100%; height:100%; display:none; ">
<h2>Success! Your Message was Sent Successfully.</h2>
</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
	</script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
  
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>
    </body>
</html>