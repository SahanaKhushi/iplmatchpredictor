<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>match predictor</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
		<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<style>
		
	
		
		
		
.dropdown-submenu {
  position: relative;
}

.dropdown-submenu .dropdown-menu {
  top: 0;
  left: 100%;
  margin-top: -1px;
}




body {
   
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 300px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 6px 6px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.button5 {background-color: #555555;}

.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
    </head>
    <body style="background-image: url('images/ipl6.jpg'); background-repeat: no-repeat;">
	<div class="sidenav">
	<a href="final webapp\DevFolio\index.html">IPL 20-20</a><br><br>
	<a href="main1.php">Home</a><br><br>
<a href="final webapp\DevFolio\pastperformance.html">Past Performance</a><br><br>
<a href="select.php">IPL Match Predictor</a><br><br>
  <a href="select2.php">IPL Season Predictor</a><br><br>
  <a href="final webapp\New folder\charts\HTML-Table-Based-Column-Chart-Plugin-For-jQuery-graph-js/index.html">IPL Team Performance</a><br><br>
  <a href="logout.php">Logout</a><br>
    
</div>
        <div class="container">
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-9 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <form id="reused_form" name=form1 action="insert.php" method="post">
                                    <div class="main">
 
</div><br><br><br>


	<div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
		<div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
			<form class="contact100-form validate-form">
				<span class="contact100-form-title">
					IPl 20-20 Match Predictor
				</span>
				
	<!--<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.js"></script>
	<script type="text/javascript" class="foo">
	$(function(){
		$('select.city').change(function(){ // when one changes
			$('select.venue').val( $(this).val() ) // they all change
		})
	})
	</script>-->
	
	
	
				<div class="wrap-input100 input100-select">
					<span class="label-input100">City</span>
					<div>
						<select class="selection-2"id="city" name="city">
  <option value="111" >Hyderabad</option>
  <option value="222" >Pune</option>
  <option value="333" >Rajkot</option>
  <option value="444" >Indore</option>
  <option value="555" >Bangalore</option>
  <option value="666" >Mumbai</option>
  <option value="777" >Kolkata</option>
  <option value="888" >Delhi</option>
  <option value="999" >Chandigarh</option>
  <option value="101010" >Kanpur</option>
  <option value="111111" >Jaipur</option>
  <option value="121212" >Chennai</option>
  <option value="131313" >Cape Town</option>
  <option value="141414" >Port Elizabeth</option>
  <option value="151515" >Durban</option>
  <option value="161616" >Centurion</option>
  <option value="171717" >East London</option>
  <option value="181818" >Johannesburg</option>
  <option value="191919" >Kimberley</option>
  <option value="202020" >Bloemfontein</option>
  <option value="212121" >Ahmedabad</option>
  <option value="222222" >Cuttack</option>
</select>
</div>
<span class="focus-input100"></span>
</div>

<div class="wrap-input100 input100-select">
					<span class="label-input100">Venue</span>
					<div>
						<select class="selection-2" name="venue" id="venue">
  <option value="111">Rajiv Gandhi International Stadium, Uppal</option>
  <option value="222">Maharashtra Cricket Association Stadium</option>
   <option value="333" >Saurashtra Cricket Association Stadium</option>
  <option value="444">Holkar Cricket Stadium</option>
  <option value="555" >M Chinnaswamy Stadium</option>
  <option value="666" >Wankhede Stadium</option>
  <option value="777" >Eden Gardens</option>
  <option value="888" >Feroz Shah Kotla</option>
  <option value="999" >Punjab Cricket Association IS Bindra Stadium, Mohali</option>
  <option value="101010" >Green Park</option>
  <option value="111111" >Sawai Mansingh Stadium</option>
  <option value="121212" >MA Chidambaram Stadium, Chepauk</option>
  <option value="131313" >Newlands</option>
  <option value="141414" >St George's Park</option>
  <option value="151515" >Kingsmead</option>
  <option value="161616" >SuperSport Park</option>
  <option value="171717" >Buffalo Park</option>
  <option value="181818" >New Wanderers Stadium</option>
  <option value="191919" >De Beers Diamond Oval</option>
  <option value="202020" >OUTsurance Oval</option>
  <option value="212121" >Sardar Patel Stadium, Motera</option>
  <option value="222222" >Barabati Stadium</option>

</select>
</div>
	<span class="focus-input100"></span>
				</div>
	
	
	
	<div class="wrap-input100 input100-select">
					<span class="label-input100">Team 1</span>
					<div>
						<select class="selection-2" name="team1" id="team1">
						<option>Chennai Super Kings</option>
						<option >Royal Challengers Bangalore</option>
							<option>Mumbai Indians</option>
							<option>Kings XI Punjab</option>
							<option>Delhi Capitals</option>
							<option>Rajasthan Royals</option>
							<option>SunRisers Hyderabad</option>
							<option>Kolkata Knight Riders</option>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Team 2</span>
					<div>
						<select class="selection-2" name="team2" id="team2">
						<option >Royal Challengers Bangalore</option>
						<option>Chennai Super Kings</option>
							<option>Mumbai Indians</option>
							<option>Kings XI Punjab</option>
							<option>Delhi Capitals</option>
							<option>Rajasthan Royals</option>
							<option>SunRisers Hyderabad</option>
							<option>Kolkata Knight Riders</option>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				
				
           <div class="wrap-input100 input100-select">
					<span class="label-input100">Toss won by</span>
					<div>
					<select class="selection-2" name="toss" id="toss">
					<option>Team 1</option>
					<option>Team 2</option>
				    </select>
					</div>
				
				</div>
				
				
				

	
	
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Toss Decision</span>
					<div>
					<select class="selection-2" name="decision" id="decision">
					
							<option>Field</option>
							<option>Bat</option>
							</select>
						
					</div>
					<span class="focus-input100"></span>
				</div>

	<!--<input type="submit" value="submit">-->
				
				
	
				
				

				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div><button class="contact100-form-btn" style="background-color:Black;">
                        <a href="result.php">
							
							<input type="submit" value="Predict">
								
						</a>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>



	<div id="dropDownSelect1"></div>
                                </form>
                                <div id="error_message" style="width:100%; height:100%; display:none; ">
                                    <h4>
                                        Error
                                    </h4>
                                    Sorry there was an error sending your form. 
                                </div>
                                <div id="success_message" style="width:100%; height:100%; display:none; ">
<h2>Success! Your Message was Sent Successfully.</h2>
</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
	</script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
  
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>
    </body>
</html>