<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "demo");
header("Location: result.php");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$city = mysqli_real_escape_string($link, $_REQUEST['city']);
$venue = mysqli_real_escape_string($link, $_REQUEST['venue']);
$team1 = mysqli_real_escape_string($link, $_REQUEST['team1']);
$team2 = mysqli_real_escape_string($link, $_REQUEST['team2']);
$toss = mysqli_real_escape_string($link, $_REQUEST['toss']);
$decision = mysqli_real_escape_string($link, $_REQUEST['decision']);

 
// Attempt insert query execution
$sql = "INSERT INTO matchpredict (city, venue, team1, team2, toss, decision) VALUES ('$city', '$venue', '$team1', '$team2', '$toss', '$decision')";
	   //}
	
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
   //}
// Close connection
mysqli_close($link);
?>